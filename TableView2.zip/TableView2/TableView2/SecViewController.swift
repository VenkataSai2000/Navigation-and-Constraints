//
//  SecViewController.swift
//  TableView2
//
//  Created by Pulipati Venkata Sai on 06/10/22.
//

import UIKit

class SecViewController: UIViewController {
    var about=""

    @IBOutlet weak var Lbl_Name: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        Lbl_Name.text=about
        
    }
    

    

}
